export class CreateStudentDto {}
