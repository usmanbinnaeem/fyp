export class CreateSubscriptionDto {}
