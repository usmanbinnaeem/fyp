export enum Role {
  Parent = 'parent',
  Driver = 'driver',
  Admin = 'admin',
}
