export class CreatePackageDto {}
