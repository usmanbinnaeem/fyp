import React from 'react'
import EditDriver from "./edit-driver"
import DriversList from "./drivers-list"

const Drivers = () => {
    return (
        <div className='grid grid-cols-2 gap-4 text-black'>

            <div className='bg-gray-50 rounded-lg'>
                <h3 className='px-4 pt-4 pb-0 text-xl font-bold'>Drivers List</h3>
                <DriversList />
            </div>
            <div className='bg-gray-50 rounded-lg'>
                <h3 className='px-4 pt-4 pb-0 text-xl font-bold'>Edit Driver</h3>
                <EditDriver />
            </div>
        </div>
    )
}

export default Drivers