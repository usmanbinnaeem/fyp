import React from 'react'
import AddSchool from "./add-school"
import SchoolsList from "./schools-list"

const Schools = () => {
    return (
        <div className='grid grid-cols-2 gap-4 text-black'>

            <div className='bg-gray-50 rounded-lg'>
                <h3 className='px-4 pt-4 pb-0 text-xl font-bold'>Shools List</h3>
                <SchoolsList />
            </div>
            <div className='bg-gray-50 rounded-lg'>
                <h3 className='px-4 pt-4 pb-0 text-xl font-bold'>Add New School</h3>
                <AddSchool />
            </div>
        </div>
    )
}

export default Schools