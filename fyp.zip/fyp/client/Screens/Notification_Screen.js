import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  Image,
  useState,
} from "react-native";
import Notification_Button from "../components/Notification_Button";
export default function NotificationScreen() {
  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={{}}>
        <Notification_Button
          heading="Lorem ipsum "
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="Lorem ipsum dolor"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="Lorem ipsum "
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="Lorem ipsum"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="Lorem ipsum"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="ipsum consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="ipsum consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="ipsum consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="ipsum consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="ipsum consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="ipsum consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="ipsum consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
        <Notification_Button
          heading="ipsum consectetur"
          paragraph="Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia"
        />
      </View>
    </ScrollView>
  );
}
