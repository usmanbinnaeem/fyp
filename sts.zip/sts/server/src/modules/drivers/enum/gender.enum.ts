/* eslint-disable prettier/prettier */
export enum Gender {
    Boys = 'boys',
    Girls = 'girls',
    Both = 'both'
}  