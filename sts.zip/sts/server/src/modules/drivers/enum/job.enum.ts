/* eslint-disable prettier/prettier */
export enum JobType {
  Private = 'private',
  Public = 'public',
}
