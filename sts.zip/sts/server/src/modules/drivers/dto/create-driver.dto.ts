import { IsOptional, IsNotEmpty, IsIn } from 'class-validator';
import { User } from '../../users/entities/user.entity';
import { JobType } from '../enum/job.enum';
import { Gender } from '../enum/gender.enum';

export class CreateDriverDto {
  @IsNotEmpty()
  name: string;

  @IsNotEmpty()
  cnic: string;

  @IsNotEmpty()
  licenseNo: string;

  @IsOptional()
  address_line_1: string;

  @IsOptional()
  address_line_2: string;

  @IsOptional()
  city: string;

  @IsOptional()
  state: string;

  @IsOptional()
  zip: string;

  @IsOptional()
  approved: boolean;

  @IsOptional()
  profileImageUrl: string;

  @IsOptional()
  licenseImageUrl: string;

  @IsOptional()
  charges: number;

  @IsIn(['private', 'public'])
  jobType: JobType;

  @IsIn(['girls', 'boys', 'both'])
  gender: Gender;

  @IsOptional()
  user: User;
}
