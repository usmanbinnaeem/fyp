import { IsIn, IsNotEmpty, IsOptional } from 'class-validator';
import { Driver } from '../../drivers/entities/driver.entity';
import { VehicleType } from '../enum/vehicle.enum';

export class CreateVehicleDto {
  @IsNotEmpty()
  regNo: string;

  @IsNotEmpty()
  seats_capacity: string;

  @IsOptional()
  booked_seats: string;

  @IsOptional()
  color: string;

  @IsOptional()
  modal: number;

  @IsOptional()
  verified: string;

  @IsIn(['car', 'bus', 'bolan', 'suzuki'])
  vehicleType: VehicleType;

  @IsOptional()
  driver: Driver;
}
