/* eslint-disable prettier/prettier */
export enum VehicleType {
  Car = 'car',
  Bus = 'bus',
  Suzuki = 'suzuki',
  Bolan = 'bolan',
}
