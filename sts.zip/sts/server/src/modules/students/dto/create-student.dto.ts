export class CreateStudentDto {}
