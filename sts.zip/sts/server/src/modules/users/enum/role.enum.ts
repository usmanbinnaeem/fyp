/* eslint-disable prettier/prettier */
export enum Role {
  Parent = 'parent',
  Driver = 'driver',
  Admin = 'admin',
}
