export class CreateSubscriptionDto {}
