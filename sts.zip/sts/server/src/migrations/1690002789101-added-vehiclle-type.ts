import { MigrationInterface, QueryRunner } from "typeorm";

export class addedVehiclleType1690002789101 implements MigrationInterface {
    name = 'addedVehiclleType1690002789101'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "vehicle"
            ADD "vehicleType" character varying NOT NULL
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "vehicle" DROP COLUMN "vehicleType"
        `);
    }

}
