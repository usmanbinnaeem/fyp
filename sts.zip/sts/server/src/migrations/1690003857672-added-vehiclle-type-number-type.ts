import { MigrationInterface, QueryRunner } from "typeorm";

export class addedVehiclleTypeNumberType1690003857672 implements MigrationInterface {
    name = 'addedVehiclleTypeNumberType1690003857672'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "vehicle" DROP COLUMN "modal"
        `);
        await queryRunner.query(`
            ALTER TABLE "vehicle"
            ADD "modal" integer
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "vehicle" DROP COLUMN "modal"
        `);
        await queryRunner.query(`
            ALTER TABLE "vehicle"
            ADD "modal" character varying NOT NULL
        `);
    }

}
