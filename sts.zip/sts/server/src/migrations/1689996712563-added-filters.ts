import { MigrationInterface, QueryRunner } from "typeorm";

export class addedFilters1689996712563 implements MigrationInterface {
    name = 'addedFilters1689996712563'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "vehicle" DROP COLUMN "report"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "accountNo"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "accountName"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "accountType"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "charges" integer
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "gender" character varying NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "jobType" character varying NOT NULL
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "jobType"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "gender"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "charges"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "accountType" character varying
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "accountName" character varying
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "accountNo" character varying
        `);
        await queryRunner.query(`
            ALTER TABLE "vehicle"
            ADD "report" character varying
        `);
    }

}
