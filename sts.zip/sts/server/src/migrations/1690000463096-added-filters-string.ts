import { MigrationInterface, QueryRunner } from "typeorm";

export class addedFiltersString1690000463096 implements MigrationInterface {
    name = 'addedFiltersString1690000463096'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "charges"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "charges" character varying
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "charges"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "charges" integer
        `);
    }

}
