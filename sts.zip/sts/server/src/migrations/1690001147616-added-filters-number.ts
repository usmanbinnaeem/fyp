import { MigrationInterface, QueryRunner } from "typeorm";

export class addedFiltersNumber1690001147616 implements MigrationInterface {
    name = 'addedFiltersNumber1690001147616'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "charges"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "charges" integer
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "driver" DROP COLUMN "charges"
        `);
        await queryRunner.query(`
            ALTER TABLE "driver"
            ADD "charges" character varying
        `);
    }

}
