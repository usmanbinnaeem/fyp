import React from "react";
import { Text, View } from "react-native";
const LiveMap = () => {
  return (
    <View>
      <Text>Maps</Text>
    </View>
  );
};

export default LiveMap;
