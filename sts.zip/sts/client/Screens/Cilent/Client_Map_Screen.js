import React from "react";
import { StyleSheet, Text, View, Image, ScrollView } from "react-native";
const LiveMap = () => {
  return(
<View>
  <Text>
    client Maps
  </Text>
</View>

  ) 
};

export default LiveMap;
