import { useState, useEffect } from "react";
import { ScrollView, View, Text } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Info_Button from "../../components/Info_Button";
const BASE_URL = "http://192.168.43.47:5000";

const jobTypeOptions = ["private", "public"];
const genderOptions = ["boys", "girls", "both"];
const vehicleTypeOptions = ["car", "bus", "bolan", "suzuki"];
const modalOptions = [
  2000, 2001, 2001, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012,
  2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023,
];

export default function Find_Client_Driver({ navigation }) {
  const [charges, setCharges] = useState(0);
  const [gender, setGender] = useState("both");
  const [jobType, setJobType] = useState("private");
  const [vehicleType, setVehicleType] = useState("suzuki");
  const [modal, setModal] = useState(2000);
  const [drivers, setDrivers] = useState([]);

  const fetchData = async () => {
    try {
      // const token = await AsyncStorage.getItem("token");
      const response = await fetch(`${BASE_URL}/drivers`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          // Authorization: "Bearer " + token,
        },
      });

      const json = await response.json();
      setDrivers(json);
    } catch (error) {
      console.error(error);
    }
  };

  const getFilteredDrivers = async () => {
    try {
      // const token = await AsyncStorage.getItem("token");
      const response = await fetch(
        `${BASE_URL}/drivers/filters?charges=${charges}&gender=${gender}&jobType=${jobType}&vehicleType=${vehicleType}&modal=${modal}`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            // Authorization: "Bearer " + token,
          },
        }
      );

      const json = await response.json();
      setDrivers(json);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.container}>
        <TextInput
          style={styles.input}
          placeholder="Charges"
          onChangeText={setCharges}
          keyboardType="numeric"
          value={charges}
        />

        <View style={styles.pickerContainer}>
          <Picker
            style={styles.picker}
            selectedValue={vehicleType}
            onValueChange={(itemValue) => setVehicleType(itemValue)}
          >
            {vehicleTypeOptions.map((vehicleType, index) => (
              <Picker.Item
                key={index}
                label={vehicleType}
                value={vehicleType}
              />
            ))}
          </Picker>
        </View>

        <View style={styles.pickerContainer}>
          <Picker
            style={styles.picker}
            selectedValue={modal}
            onValueChange={(itemValue) => setModal(itemValue)}
          >
            {modalOptions.map((modal, index) => (
              <Picker.Item key={index} label={modal} value={modal} />
            ))}
          </Picker>
        </View>

        <View style={styles.pickerContainer}>
          <Picker
            style={styles.picker}
            selectedValue={gender}
            onValueChange={(itemValue) => setGender(itemValue)}
          >
            {genderOptions.map((gender, index) => (
              <Picker.Item key={index} label={gender} value={gender} />
            ))}
          </Picker>
        </View>

        <View style={styles.pickerContainer}>
          <Picker
            style={styles.picker}
            selectedValue={jobType}
            onValueChange={(itemValue) => setJobType(itemValue)}
          >
            {jobTypeOptions.map((jobType, index) => (
              <Picker.Item key={index} label={jobType} value={jobType} />
            ))}
          </Picker>
        </View>

        <Button title="Filter" onPress={getFilteredDrivers} />
        <Button title="Reset" onPress={fetchData} />
      </View>
      <View>
        {drivers.length ? (
          drivers.map((d) => (
            <Info_Button
              name={d.name}
              imagelink={require("../../assets/Rectangle1308.png")}
              area="Supply-Mandian"
              charges="6000"
              rating="4.6"
              onPress={() => {
                navigation.navigate("DriverDetails", {
                  driver: d,
                });
              }}
            />
          ))
        ) : (
          <Text>No driver registered yet</Text>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#fff",
  },
  input: {
    height: 30,
    borderColor: "gray",
    borderWidth: 1,
    marginBottom: 5,
    paddingLeft: 10,
    borderRadius: 5,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: "gray",
    borderRadius: 5,
    marginBottom: 5,
    overflow: "hidden", // For Android
  },
  picker: {
    height: Platform.OS === "ios" ? 200 : 30, // Different height for iOS and Android
  },
  driverContainer: {
    padding: 10,
    backgroundColor: "#f0f0f0",
    marginTop: 10,
    borderRadius: 5,
  },
});
